# <YOUR_IMPORTS>

def predict():
    # <YOUR_CODE>
    pass


if __name__ == '__main__':
    predict()
